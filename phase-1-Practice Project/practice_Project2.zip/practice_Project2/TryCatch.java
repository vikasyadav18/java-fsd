package practice_Project2;


class Ny
{int i=5,j=0;
void mth()
{
	try
	{
	int k=i/j;
	System.out.println(k);
	}
	catch(Exception e)
	{System.out.println("error is found");
	System.out.println(e.getMessage());
	}


}


}
class TryCatch
{public static void main(String []args)
{

Ny ob=new Ny();
ob.mth();


}

}