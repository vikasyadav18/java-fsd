package practice_Project2;

class ThreadDemo
{
	public static void main (String []args) 
	{
		thread1 ob1=new thread1();
		thread2 ob2=new thread2();
		ob1.start();
		ob2.start();
	}
}
class thread1 extends Thread 
{
	public void run()
	{
		for (int i=0;i<10;i++)
		{
			System.out.println("hello , i am thread 1");
			try
			{
				Thread.sleep(3000L);
			}
			catch(InterruptedException e) 
			{
				e.printStackTrace();
			}
		}
	}
}
class thread2 extends Thread  
{
	public void run()
	{
		for (int i=0;i<10;i++)
		{
			System.out.println("hello i am thread 2");
			try 
			{
				Thread.sleep(3000L);
			}
			catch(InterruptedException e)
			{ 
				e.printStackTrace();
			}
		}
	}
}
