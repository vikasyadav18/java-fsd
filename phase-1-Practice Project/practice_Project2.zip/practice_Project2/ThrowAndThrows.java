package practice_Project2;


//custom exception

class ThrowAndThrows
{
	public static void main (String []arg)
	{
		Test ob=new Test();
		System.out.println("take off");
		System.out.println();
		ob.go();

		demoThrows ob2=new demoThrows();
		ob2.fun(18);
	}
}
class VsException extends Exception
{public VsException(String s)
	{
		super(s);
	} 	
}

class  Test
{
	void go()
	{
		try {
			throw new VsException("error error error");
			
		}
		catch(VsException e){
			System.out.println("found");
			System.out.println(e.getMessage());
			
		}		
	}	
}

class demoThrows 
{
	void fun(int a) throws ArithmeticException
	{
		if(a<18)
		{
			throw new ArithmeticException("Access denied - You must be at least 18 years old.");
		}
		else
		{
			System.out.println("age is equal or greater to 18");
		}
	}
}
