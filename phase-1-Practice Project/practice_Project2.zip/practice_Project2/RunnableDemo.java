package practice_Project2;

public class RunnableDemo
{
	public static void main(String [] args)
	{
		Runnable ob1=new Threadde();
		Thread obj1=new Thread(ob1);
		obj1.start();
	}
}

class Threadde implements Runnable
{
	public void run()
	{
		for (int i=0;i<=3;i++)
		{
			System.out.println("hey i am a another thread using runnable interface");
			try
			{Thread.sleep(4000L);
			}	
			catch(InterruptedException e)
			{
				e.printStackTrace();		// throwable class method 
				
			}
		}
	}
	
}