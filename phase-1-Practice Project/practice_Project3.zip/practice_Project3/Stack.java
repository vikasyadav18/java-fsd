package practice_Project3;


import java.util.*;
class element
{
	int data;
    element next;
}

class stack1
{
    element top;
    stack1()
    {
        top=null;
    }
    
    void push()
    {       
        System.out.println("enter the element ");
        Scanner sc=new Scanner(System.in);
        int i=sc.nextInt();
        element newnode=new element();
        
        newnode.data=i;
        newnode.next=top;
        top=newnode;        
    }
    
    void pop()
    {
        if(top==null)
        {
            System.out.println("under flow"); 
        }
        
        else 
        {
            System.out.println("value is: "+top.data);
            top=top.next;
        }
    }
    
    void traverse()
    {
        if(top==null)
        {
           System.out.println("stack is empty");
        }
        else 
        {
           System.out.println("stacks element");
           for(element x=top;x!=null;x=x.next)
           {
               System.out.println(x.data);
           }
        }
    }  
}

public class Stack
{
	public static void main(String[] args)
	{
	    Scanner sc=new Scanner(System.in);	    
	    stack1 obj=new stack1();
	    while(true)
	    {
		System.out.println("enter 1 for push");
		System.out.println("enter 2 for pop");
		System.out.println("enter 3 for traverse");
	    int j=sc.nextInt();
	    switch(j)
	    {
	        case 1:obj.push();
	        break;
	        case 2:obj.pop();
	        break;
	        case 3:obj.traverse();
	        break;
	        default:
	        System.out.println("wrong input");  
	    }
	    }
	}
}

