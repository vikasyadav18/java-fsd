package practice_Project3;
import java.util.*;

class Node2 
{
	int data;
	Node2 next ;
	Node2 prev;
	
}
class DoublyLinkedList
{
	Node2 head;
	Node2 tail;
	
	DoublyLinkedList()
	{
		head=tail=null;
	}
	
	void insert()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the element");
		int d=sc.nextInt();
		Node2 obj=new Node2();
		
		obj.data=d;
		
		if(head==null)
		{
			head=tail=obj;
			return;
		}
		else
		{
			tail.next=obj;
			obj.prev=tail;
			tail=obj;
			tail.next=null;
			
		}
		
		
	}
	
	
	void FrontTraverse()
	{
		Node2 current;
		
		System.out.println("...........elements are............");
		for(current=head;current!=null;current=current.next)
		{
			System.out.println(" "+current.data);
			
		}
		
	}
	
	void BackTraverse()
	{
		Node2 current;
		System.out.println("...........elements are............");
		for(current=tail;current!=null;current=current.prev)
		{
			System.out.println(current.data);
		}
	}

}


class DoublyLinked
{
	static Scanner sc =new Scanner(System.in);
	public static void main(String []args)
	{
		DoublyLinkedList obj=new DoublyLinkedList();
		
		while(true)
		{
			System.out.println("enter 1 for insert elements");
			System.out.println("enter 2 for FrontTraverse of elements");
			System.out.println("enter 3 for BackTraverse of elements");
			
			
			int i=sc.nextInt();
			switch(i)
			{
				case 1:
				obj.insert();
				break;

				case 2:
				obj.FrontTraverse();
				break;
				
				case 3:
				obj.BackTraverse();
				break;
				
				default :
				System.out.println("wrong input");
				break;
				
				
				
			}
		
		
		}
	
	}
	
}
