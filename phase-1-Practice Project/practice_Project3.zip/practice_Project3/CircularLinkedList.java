package practice_Project3;

import java.util.*;
class Node1
{
	int data;
	Node1 next;
}

public class CircularLinkedList {
 
	Node1 head;
	static 	Scanner sc=new Scanner(System.in);
	CircularLinkedList()
	{
		 head=null;
	}
	
	void Node1Add()
	{
		System.out.println("enter the data");
	
		int n=sc.nextInt();
		Node1 obj=new Node1();
		//obj.next=null;
		obj.data=n;
		
		if(head==null)
		{
			head=obj;
			head.next=obj;
			
		
		}
		else
		{
		Node1 current=head;
		while(current.next!=head)
		{
			current=current.next;
			
		}
		
		current.next=obj;
		obj.next=head;
		
		}
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CircularLinkedList ob=new CircularLinkedList();
		
		while(true)
		{
			System.out.println("1. for enter data");
			System.out.println("2. for exit");
			
			int n=sc.nextInt();
			switch(n)
			{
				case 1:ob.Node1Add();
				break;
				
				case 2:System.exit(0);
				
			}
			
		}
	}
	

}
