package practice_Project3;

import java.util.*;

class Node{
	int data;
	Node next;
}

public class LinkedList 
{
	Node head;
	LinkedList()
	{
		head=null;
	}
	
	static Scanner sc=new Scanner(System.in); 

	void addNode()
	{
		Node newNode=new Node();
		
		System.out.println("enter the data");
		int data=sc.nextInt();
		newNode.data=data;
		newNode.next=null;
		
		if(head==null)
		{
			head=newNode;
		}
		else
		{
			Node current = head;
			while(current.next!=null)
			{
				current=current.next;
			}
			current.next=newNode;
			
		}
		
		
	}
	
	void Delete()
	{
		if(head!=null)
		{
			head=head.next;
		}
		else {
			System.out.println("no item found");
			return;
		}
	}
	
	void traverse()
	{
		
		Node current =head;
		if(head==null)
		{
			System.out.println("list is empty");
			return;
		}
		
		while(current.next!=null)
		{
			System.out.println(current.data);
			current=current.next;
		}
		System.out.println(current.data);
		
	}
		

		public static void main(String[] args) 
		{
			// TODO Auto-generated method stub
			
			LinkedList obj=new LinkedList();
		        while (true)
		        {
		            System.out.println("1. add");
		            System.out.println("2. delete");
		            System.out.println("3.traverse");
		            System.out.println("4. exit");

		            System.out.println("enter ur choice");
		            
		            int ch=sc.nextInt();

		            switch(ch)
		            {
		                case 1:
		                    obj.addNode();
		                    break;
		                case 2:obj.Delete();
		                	break;
		                case 3:
		                    obj.traverse();
		                    break;
		                case 4:
		                    System.exit(0);
		                    break;
		                default:
		                    System.out.println("wrong choice");
		            }

		        }
		}
	

}
