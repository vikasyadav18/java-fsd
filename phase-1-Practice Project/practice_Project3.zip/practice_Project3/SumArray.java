package practice_Project3;

public class SumArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int arr[]= {1,2,15,6,4,8,9,6,54,8,4,6};
		int l=3; //l>=0
		int r=10; //r<=arr.length-1;
		int sum=0;
		for(int i=l-1;i<r-1;i++)
		{
			sum=sum+arr[i];
		}
		System.out.println(sum);
	}

}
