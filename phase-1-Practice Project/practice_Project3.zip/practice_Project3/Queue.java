package practice_Project3;

import java.util.*;

class node3 
{
	int data;
	node3 next;
	node3()
	{
		next=null;
		
	}
}


class Mynode3
{
	static Scanner sc=new Scanner(System.in);
	node3 rear;
	node3 front;
	
	Mynode3()
	{
		rear=null;
		front=null;
		
	}
	
	void enqueue()
	{
		System.out.println("enter the element");
		
		int i=sc.nextInt();
	    node3 newnode3=new node3();
		newnode3.data=i;
		newnode3.next=null;
		
		
		
		if(front==null)
		{
			front=newnode3;
			return;
			
		}
	
		else
		{
			rear=front;
			while(rear.next!=null)
			{
				rear=rear.next;
				
			}
			
			rear.next=newnode3;
			
			
			
		}
	
	}
	
	void dequeue()
	{
		
		
		if(front==null)
		{
			rear=null;
			
			System.out.println("Queue is empty");
			return;
			
		}
		
		System.out.println("deleted : "+front.data);
		front=front.next;
			    
	}
	
	void peek()
	{
		node3 temp=front;
		
		if(temp==null)
		{
			System.out.println("Queue is empty");
			return;
		}
		
		for(temp=front;temp!=null;temp=temp.next)
		{
			System.out.println(temp.data);
			
		}
	}		
}

class Queue
{
	static Scanner sc=new Scanner(System.in);
	public static void  main (String []args)
	{
		Mynode3 ob=new Mynode3();
		
		while(true)
		{
		System.out.println("press 1 for adding rollno");
		System.out.println("press 2 for deletion rollno");
		System.out.println("press 3 for traversing rollno");
		
			int i=sc.nextInt();
			switch(i)
			{
				case 1:
				ob.enqueue();
				break;
					
				case 2:
				ob.dequeue();
				break;
					
				case 3:
				ob.peek();
				break;					
					
				default :
				System.out.println("wrong input");										
			}	
		}
	}
}

