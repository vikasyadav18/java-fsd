package practice_Project3;

import java.util.Arrays;

public class RotateArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {1,2,3,4,5,6};  // 4,5,6,1,2,3
			int n=3;
			int last=0;
			
			for(int i=0;i<n;i++)
			{
				last=arr[arr.length-1];
				for(int j=arr.length-1;j>0;j--)
				{
					
					arr[j]=arr[j-1];
					 
				}
				arr[0]=last;
			}
			System.out.println(Arrays.toString(arr));

	}
}
