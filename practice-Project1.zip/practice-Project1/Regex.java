package practice_Project1;

import java.util.regex.Matcher;
import java.util.regex.Pattern;  //or import java.util.regex.*; that means "all" classes of regex are imported
import java.util.*;

public class Regex
{
	public static void main(String[] args) 										// java.util.regex;
															//1.class Pattern
															
														        //a.static compile(); method
	{
	    	Scanner sc = new Scanner(System.in);								        //2. class Matcher
															//a. static matcher(); method
		System.out.println("enter the mobile no ");								//b. find();  method
															//c. group(); method	    						
		String text = sc.nextLine();										
		String regex = "((\\+91|0)?[6-9]\\d{9})";								
		Pattern p = Pattern.compile(regex);										
		Matcher m = p.matcher(text);
		ArrayList<String> mobile = new ArrayList<>();
		while(m.find())
		{
			String obj = m.group();
		//	System.out.println(obj);
			mobile.add(obj);

		}

        for(String s:mobile)
        {
           		System.out.print(" "+s); 
        }
	}
}

