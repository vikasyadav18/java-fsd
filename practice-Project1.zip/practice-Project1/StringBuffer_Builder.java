package practice_Project1;

public class StringBuffer_Builder {
	public static void main(String args[])
	{
		String s="hello";
		StringBuilder sbd=new StringBuilder(s);
		StringBuffer sbf=new StringBuffer();
		
		System.out.println(s.getClass().getName());
		System.out.println(sbd.getClass().getName());
		System.out.println(sbf.getClass().getName());
	}
}
