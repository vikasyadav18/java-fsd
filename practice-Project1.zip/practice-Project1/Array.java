package practice_Project1;

public class Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]=new int[5];
		arr[0]=1;
		arr[1]=2;
		arr[2]=3;

		arr[4]=5;
		
		for(int i=0;i<5;i++)
		{
			System.out.println(arr[i]);
		}

	}

}
