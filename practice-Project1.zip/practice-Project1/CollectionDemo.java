package practice_Project1;

import java.util.*;

public class CollectionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		  //creating hashset
	       HashSet<Integer> set=new HashSet<Integer>();  
	       set.add(1);  
	       set.add(3);  
	       set.add(4);
	       set.add(5);
	       System.out.println(set);
		//creating vector
	     
	      Vector<Integer> vec = new Vector();
	      vec.addElement(2); 
	      vec.addElement(3); 
	      System.out.println(vec);
		
		//creating linkedlist
	      LinkedList<Integer> ls=new LinkedList<>();  
	      ls.add(1);  
	      ls.add(2);  	      
	      Iterator<Integer> itr=ls.iterator();  
	      while(itr.hasNext()){  
	       System.out.println(itr.next());  
	       
	     
	     //creating arraylist
			System.out.println("ArrayList");
			ArrayList<Integer> num=new ArrayList<>();   
		      num.add(1);//
		      num.add(2);    	   
		      System.out.println(num);  
			
	       
	}

	}
}

