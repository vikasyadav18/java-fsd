package practice_Project1;

// two types of constructor in java 1-Parameterized 2-non Parameterized

public class Constructor {

	Constructor()
	{
		System.out.println("non parameterized constructor is called "); 
	}
	
	Constructor(int a)
	{
		System.out.println("value is "+a);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Constructor ob1=new Constructor();
		Constructor ob2=new Constructor(25);
		
		
	}

}
