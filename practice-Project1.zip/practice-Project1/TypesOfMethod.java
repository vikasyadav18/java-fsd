package practice_Project1;

//there are three types of calling in java method 1=Parameters and Arguments 2= no Parameters and no Arguments and also form constructor

public class TypesOfMethod 
{
	
	// This method is called when the object of this class is made.
	public TypesOfMethod() {
		// TODO Auto-generated constructor stub
		System.out.println("This is constructor calling.");
	}
	
	// Parameters and Arguments
	
	void demo1(int a)
	{
		System.out.println("callng this method by passing parameters that is: " +a);
	}
	
	//No Parameters 
	void demo2()
	{
		System.out.println("callng this method without passing any parameters.");
	}
	
	public static void main(String args[])
	{
		TypesOfMethod ob=new TypesOfMethod();
		ob.demo1(10);
		ob.demo2();
		
	}

}
