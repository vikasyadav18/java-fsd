package practice_Project1;
import java.util.*;

public class Map {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 HashMap map=new HashMap();  
		    //Adding elements to map  
		    map.put(1,"vik");  
		    map.put(2,"nik");  
		    map.put(3,"rik");  
		    map.put(4,"mik"); 
		    
		    
		        System.out.println(map);  
		      
	}

}
