package practice_Project1.access_modifier.Default;

//The default modifier is accessible only within package. It cannot be accessed from outside the package. It provides more accessibility than private. But, it is more restrictive than protected, and public.

class A{  
	  void msg(){System.out.println("Hello");}  
	}  