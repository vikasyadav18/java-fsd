package practice_Project1.access_modifier.PublicPack_A;

public class A {
	public void msg()
	{
		System.out.println("Hello from Public method with different package");
		}  
}
