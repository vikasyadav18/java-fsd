/*package access_modifier;
//The access level of a private modifier is only within the class. It cannot be accessed from outside the class.
class A{  
private int data=40;  
private void testmethod(){System.out.println("Hello java");}  
} 

public class Private {
	 public static void main(String args[]){  
		   A obj=new A();  
		   System.out.println(obj.data);//The field A.data is not visible
  
		   obj.testmethod();//The method testmethod() from the type A is not visible 
		   } 
}

remove this commit symbole to run.
 
 */
