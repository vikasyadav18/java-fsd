package practice_Project1.access_modifier.Protected_A;
//The protected access modifier is accessible within package and outside the package but through inheritance only.

public class A {

	protected void test()
	{
		System.out.println("Hello from A-package");
	}  


}
