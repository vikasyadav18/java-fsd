package practice_Project1.access_modifier.Protected_B;
import practice_Project1.access_modifier.Protected_A.*;
public class B extends A {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  B obj = new B();  
		   obj.test();  
	}

}
