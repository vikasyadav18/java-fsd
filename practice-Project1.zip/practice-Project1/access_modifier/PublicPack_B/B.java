package practice_Project1.access_modifier.PublicPack_B;
import practice_Project1.access_modifier.PublicPack_A.*;
public class B {
	public static void main(String args[])
	{  
		   A obj = new A();  
		   obj.msg();  
		  }  
}
